public interface MetodoPagamento {
    void realizarPagamento(double valor);
}
